CREATE TABLE FineTransactions (
  FineID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
  UserID int NOT NULL,
  Amount decimal(10, 2) NOT NULL,
  PaymentDate datetime NOT NULL,
  CONSTRAINT FK_UserID3 FOREIGN KEY (UserID) REFERENCES Users(UserID)
);